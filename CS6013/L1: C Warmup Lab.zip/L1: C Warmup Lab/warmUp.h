//
//  warmUp.h
//  L1: C Warmup Lab
//
//  Created by Jia Gao on 1/12/25.
//

#ifndef warmUp_h
#define warmUp_h

#include <stdio.h>

#endif /* warmUp_h */
